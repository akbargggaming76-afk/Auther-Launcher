# Auther Launcher 0.1
Starter project Android untuk APK prototype UI. HTML (`index.html`) adalah preview browser, bukan APK.

## Build di GitHub
1. Upload seluruh isi folder ini ke root repository GitHub, termasuk folder `.github`.
2. Buka tab Actions → Build Auther Launcher APK → Run workflow.
3. Setelah selesai, unduh artifact `Auther-Launcher-APK`.

## Catatan penting
Ini baru prototype antarmuka. Tombol Luncurkan belum menjalankan Minecraft. Agar bisa memainkan Minecraft Java, perlu integrasi runtime Android yang kompatibel, pengunduh versi dan library, pengelolaan file, Java runtime, kontrol input, serta pengujian perangkat. Versi Minecraft Java juga memerlukan aset/game yang diperoleh secara sah.
