# AUTHER Playable APK — build setup

This package adds a GitHub Actions workflow that builds an Android Minecraft Java launcher using the Amethyst runtime as its internal engine.

## Install it in your AUTHER repository

1. Download and extract this ZIP.
2. In your GitHub repository `akbargggaming76-afk/Auther-Launcher`, open **Add file → Upload files**.
3. Upload the `.github` folder from this ZIP so the final path is:
   `.github/workflows/build-auther-playable.yml`
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build AUTHER Playable APK** → **Run workflow**.
7. When the workflow finishes successfully, open the run and download the artifact named **AUTHER-Playable-Debug-APK**.

## Important limitations

- This first build uses Amethyst as the Minecraft Java runtime. The app label is changed to AUTHER, but the launcher interface is still primarily the Amethyst interface; it is not yet the custom AUTHER design/features requested.
- The workflow has not been run from this chat. A successful APK is not guaranteed until GitHub Actions completes.
- Minecraft Java itself is not included. The user must provide a legitimate Minecraft Java account/game access and download a game version inside the launcher.
- Amethyst is open-source software. Its license and notices are retained by checking out the upstream repository; review its license and comply with it before distributing modified builds.
- The Android application ID remains the upstream Amethyst ID in this first integration, so it may conflict with an installed Amethyst build.
